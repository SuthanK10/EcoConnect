Hosted Link: https://ecoconnect.42web.io/ 

Logins:

Admin:
admin@gmail.com
admin123

NOTE - WHEN REGISTERING AS USER OR NGO, PLEASE USE YOUR ACTUAL EMAIL SO YOU CAN TEST THE FORGOT PASSWORD FEATURE!!!

user: (can be registered as well)

NGOs: (can be registered as well)
